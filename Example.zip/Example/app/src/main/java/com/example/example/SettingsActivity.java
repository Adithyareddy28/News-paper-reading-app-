package com.example.example;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.net.Uri;
public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
    }
    public void myhome(View v){
        Intent i=new Intent(this,SettingsActivity.class);
        startActivity(i);
    }
    public void theHindu(View v) {
        String url = "https://epaper.thehindu.com/reader ";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }
    public void Sakshi(View v) {
        String url = "https://epaper.sakshi.com/";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }
    public void EenaduEpaper(View v) {
        String url = "https://epaper.eenadu.net/";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }
    public void Telanganatoday(View v) {
        String url = "https://epaper.telanganatoday.com/";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }
    public void Jansatta(View v) {
        String url = "https://epaper.jansatta.com/";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }
    public void HOME(View v){
        Intent i=new Intent(this,MainActivity.class);
        startActivity(i);

    }

}