package com.example.example;
import androidx.appcompat.app.AppCompatActivity;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;


public class ContactsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);
    }
    public void myhome(View v){
        Intent i=new Intent(this,MainActivity.class);
        startActivity(i);

    }
    public void CurrentAffairs(View v) {
        String url = "https://www.gktoday.in/current-affairs/";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }
    public void Sports(View v) {
        String url = "https://www.gktoday.in/current-affairs/category/sports-current-affairs/";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);}
    public void Politics(View v) {
        String url = "https://www.gktoday.in/topics/politics/";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);}
    public void Economy(View v) {
        String url = "https://www.gktoday.in/current-affairs/category/economy-current-affairs/";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);}

}

